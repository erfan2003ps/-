'use strict';
// Three-way merge. Conflicting edits are reported; no side is silently discarded.
const MISSING=Symbol('missing');
const {isDeepStrictEqual}=require('node:util');
const same=(a,b)=>a===MISSING||b===MISSING?a===b:isDeepStrictEqual(a,b);
const object=v=>v!==MISSING&&v!==null&&typeof v==='object'&&!Array.isArray(v);
function merge(base,local,remote,path,conflicts){
  if(same(local,base))return remote;
  if(same(remote,base)||same(local,remote))return local;
  if(Array.isArray(local)&&Array.isArray(remote)&&Array.isArray(base)&&[...base,...local,...remote].every(x=>object(x)&&typeof x.id==='string')){
    const maps=[base,local,remote].map(a=>new Map(a.map(x=>[x.id,x])));
    const ids=[...new Set([...maps[2].keys(),...maps[1].keys(),...maps[0].keys()])];
    return ids.map(id=>merge(...maps.map(m=>m.has(id)?m.get(id):MISSING),path+'['+id+']',conflicts)).filter(x=>x!==MISSING);
  }
  if(object(base)&&object(local)&&object(remote)){
    const output={}; for(const key of new Set([...Object.keys(base),...Object.keys(local),...Object.keys(remote)])){
      const values=[base,local,remote].map(o=>Object.prototype.hasOwnProperty.call(o,key)?o[key]:MISSING);
      const value=merge(...values,path?path+'.'+key:key,conflicts); if(value!==MISSING)Object.defineProperty(output,key,{value,enumerable:true,writable:true,configurable:true});
    }return output;
  }
  conflicts.push(path||'$'); return remote;
}
function duplicatePaths(value,path,conflicts){
  if(Array.isArray(value)){
    const seen=new Set();
    for(const item of value){
      if(object(item)&&typeof item.id==='string'){
        if(seen.has(item.id)){conflicts.push((path||'$')+'[duplicate id]');break;}
        seen.add(item.id);
      }
    }
    value.forEach((item,index)=>duplicatePaths(item,path+'['+index+']',conflicts));
  }else if(object(value))for(const key of Object.keys(value))duplicatePaths(value[key],path?path+'.'+key:key,conflicts);
}
function mergeSnapshots(base,local,remote){
  const conflicts=[];for(const value of [base,local,remote])duplicatePaths(value,'',conflicts);
  if(conflicts.length)return {value:remote,conflicts:[...new Set(conflicts)]};
  const value=merge(base,local,remote,'',conflicts);return {value,conflicts};
}
module.exports={mergeSnapshots};
