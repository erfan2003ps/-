'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs/promises');const os=require('node:os');const path=require('node:path');
const {createStore}=require('./sync-store');const {createApi}=require('./candidate-api');const {createSessions}=require('./auth-sessions');
test('two concurrent updates are preserved and subscribers are notified',async t=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'mg-integration-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));
 const store=createStore(path.join(dir,'db.json'));const base={customers:[],ws:{msgs:[]}};await store.commit({base:{},payload:base});
 const api=createApi({store,authorize:async req=>req.headers['x-test-user']?{username:'test'}:null,projectState:async(user,state)=>state,allowWrite:async()=>true});
 await new Promise(r=>api.server.listen(0,'127.0.0.1',r));t.after(()=>api.server.close());const root='http://127.0.0.1:'+api.server.address().port;
 assert.equal((await fetch(root+'/api/state')).status,401);
 const initial=await (await fetch(root+'/api/state',{headers:{'x-test-user':'a'}})).json();
 const ac=new AbortController();t.after(()=>ac.abort());const s=await fetch(root+'/api/chat/stream',{headers:{'x-test-user':'a'},signal:ac.signal});const reader=s.body.getReader();await reader.read();
 const write=payload=>fetch(root+'/api/state',{method:'POST',headers:{'content-type':'application/json','x-test-user':'a'},body:JSON.stringify({baseline:initial.baseline,payload})});
 const response=await Promise.all([write({customers:[{id:'a'}],ws:{msgs:[{id:'m',txt:'hello'}]}}),write({customers:[{id:'b'}],ws:{msgs:[]}})]);
 assert.deepEqual(response.map(r=>r.status),[200,200]);const snapshot=await store.read();assert.equal(snapshot.payload.customers.length,2);assert.equal(snapshot.payload.ws.msgs.length,1);
 assert.match(new TextDecoder().decode((await reader.read()).value),/state_updated/);
});
test('legacy user password migrates and session expires',async()=>{
 let user={username:'example',password:'test-password'},clock=0;
 const auth=createSessions({findUser:async name=>name===user.username?user:null,saveUser:async next=>{user=next},now:()=>clock,ttlMs:1000});
 assert.equal(await auth.login('example','wrong'),null);const session=await auth.login('example','test-password');assert.match(user.password,/^scrypt\$/);
 assert.equal((await auth.authenticate({headers:{cookie:session.cookie}})).username,'example');clock=1001;assert.equal(await auth.authenticate({headers:{cookie:session.cookie}}),null);
});
