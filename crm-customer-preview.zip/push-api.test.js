'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),os=require('node:os'),path=require('node:path');
const {createStore}=require('./sync-store'),{createApi}=require('./candidate-api'),{createPushManager}=require('./push-manager');
test('authenticated push subscription delivers new message only to recipient',async t=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'mg-push-api-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));
 const store=createStore(path.join(dir,'db.json'));await store.commit({base:{},payload:{users:[{username:'a'},{username:'b'}],ws:{msgs:[],tasks:[]}}});const sent=[];const transport={generateVAPIDKeys:()=>({publicKey:'public',privateKey:'private'}),setVapidDetails(){},sendNotification:async sub=>sent.push(sub.endpoint)};const pushManager=await createPushManager({filename:path.join(dir,'push.json'),transport});
 const api=createApi({store,pushManager,authorize:async req=>req.headers['x-test-user']?{username:req.headers['x-test-user']}:null,projectState:async(u,s)=>s,allowWrite:async()=>true});await new Promise(r=>api.server.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>api.server.close(r)));const root='http://127.0.0.1:'+api.server.address().port;const headers={'x-test-user':'b','content-type':'application/json'};
 assert.equal((await fetch(root+'/api/push/key')).status,401);assert.equal((await fetch(root+'/api/push/key',{headers})).status,200);
 const subscription={endpoint:'https://fcm.googleapis.com/fcm/send/test',keys:{p256dh:'A'.repeat(87),auth:'B'.repeat(22)}};assert.equal((await fetch(root+'/api/push/subscription',{method:'POST',headers,body:JSON.stringify({subscription})})).status,200);
 const h={'x-test-user':'a','content-type':'application/json'},state=await(await fetch(root+'/api/state',{headers:h})).json();state.payload.ws.msgs.push({id:'m1',from:'a',to:'b',c:'a|b'});const save=await fetch(root+'/api/state',{method:'POST',headers:h,body:JSON.stringify({baseline:state.baseline,payload:state.payload})});assert.equal(save.status,200);
 for(let n=0;n<30&&!sent.length;n++)await new Promise(r=>setTimeout(r,10));assert.deepEqual(sent,[subscription.endpoint]);
});
