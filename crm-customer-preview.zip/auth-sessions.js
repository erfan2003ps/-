'use strict';
const crypto=require('node:crypto');
const {hashPassword,verifyPassword}=require('./passwords');
function createSessions({findUser,findLoginUser=findUser,saveUser,now=()=>Date.now(),ttlMs=8*60*60*1000}){
 if(typeof findUser!=='function'||typeof saveUser!=='function')throw Error('User store required');
 const sessions=new Map();
 async function login(username,password){
  if(typeof username!=='string'||typeof password!=='string'||username.length>128||password.length>1024)return null;
  const user=await findLoginUser(username);if(!user||typeof user.password!=='string')return null;
  const legacy=!user.password.startsWith('scrypt$');
  const valid=legacy?(()=>{const a=Buffer.from(password),b=Buffer.from(user.password);return a.length===b.length&&crypto.timingSafeEqual(a,b)})():await verifyPassword(password,user.password);
  if(!valid)return null;
  if(legacy){const updated={...user,password:await hashPassword(password)};await saveUser(updated,user.password)}
  const token=crypto.randomBytes(32).toString('base64url');sessions.set(token,{username:user.username,expires:now()+ttlMs});
  return {token,cookie:'mg_session='+token+'; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age='+Math.floor(ttlMs/1000)};
 }
 async function authenticate(req){
  const raw=String(req.headers.cookie||'');const match=raw.match(/(?:^|;\s*)mg_session=([A-Za-z0-9_-]+)/);if(!match)return null;
  const session=sessions.get(match[1]);if(!session)return null;if(session.expires<=now()){sessions.delete(match[1]);return null}
  return await findUser(session.username)||null;
 }
 function logout(token){sessions.delete(token)}
 function logoutRequest(req){
  const match=String(req.headers.cookie||'').match(/(?:^|;\s*)mg_session=([A-Za-z0-9_-]+)/);
  if(match)logout(match[1]);
  return 'mg_session=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0';
 }
 return {login,authenticate,logout,logoutRequest};
}
module.exports={createSessions};
