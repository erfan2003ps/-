'use strict';
// Connections must be authorized by the integrating server before subscribing.
function createLiveEvents(){
  const clients=new Set();
  function subscribe(req,res){
    res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no'});
    res.write(': connected\n\n');clients.add(res);
    const timer=setInterval(()=>{if(!res.destroyed)res.write(': heartbeat\n\n')},25000);
    req.on('close',()=>{clearInterval(timer);clients.delete(res)});
  }
  function publish(revision){const msg='data: '+JSON.stringify({type:'state_updated',revision})+'\n\n'; for(const response of clients){try{response.write(msg)}catch{clients.delete(response)}}}
  return {subscribe,publish,count:()=>clients.size};
}
module.exports={createLiveEvents};
