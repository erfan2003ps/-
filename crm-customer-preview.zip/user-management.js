'use strict';
const crypto=require('node:crypto');
const {hashPassword,verifyPassword}=require('./passwords');
function createUserManager(store){
 async function save(actor,input){
  if(actor.role!=='admin')return {ok:false,status:403,error:'forbidden'};
  const id=typeof input.id==='string'?input.id:'';
  const username=typeof input.username==='string'?input.username.trim().toLowerCase():'';
  const displayName=typeof input.displayName==='string'?input.displayName.trim():'';
  const password=typeof input.password==='string'?input.password:'';
  const role=input.role==='admin'?'admin':'agent';
  if(!username||username.length>128||!displayName||displayName.length>200||password.length>1024||(!id&&!password))return {ok:false,status:400,error:'invalid_user'};
  const hashed=password?await hashPassword(password):null;
  return store.mutate(actor.username,async payload=>{
   if(!Array.isArray(payload.users))return {ok:false,status:400,error:'invalid_users'};
   const existing=id?payload.users.find(u=>u.id===id):null;
   if(id&&!existing)return {ok:false,status:404,error:'user_not_found'};
   if(existing&&existing.username!==username)return {ok:false,status:400,error:'username_change_not_supported'};
   if(payload.users.some(u=>(u.username.toLowerCase()===username||(u.loginName||'').toLowerCase()===username)&&u.id!==id))return {ok:false,status:409,error:'username_exists'};
   if(existing&&existing.username===actor.username&&role!=='admin')return {ok:false,status:400,error:'self_demotion_forbidden'};
   const next={...(existing||{}),id:id||'usr-'+crypto.randomBytes(12).toString('hex'),username,displayName,role,
    canDelete:role==='admin'||!!input.canDelete,canExport:role==='admin'||!!input.canExport};
   if(hashed)next.password=hashed;
   if(existing)Object.assign(existing,next);else payload.users.push(next);
   return {ok:true};
  });
 }
 async function remove(actor,id){
  if(actor.role!=='admin')return {ok:false,status:403,error:'forbidden'};
  return store.mutate(actor.username,async payload=>{
   if(!Array.isArray(payload.users))return {ok:false,status:400,error:'invalid_users'};
   const index=payload.users.findIndex(u=>u.id===id);
   if(index<0)return {ok:false,status:404,error:'user_not_found'};
   if(payload.users[index].username===actor.username)return {ok:false,status:400,error:'self_delete_forbidden'};
   payload.users.splice(index,1);return {ok:true};
  });
 }
 async function changePassword(actor,input){
  const oldPassword=input?.oldPassword, newPassword=input?.newPassword;
  if(typeof oldPassword!=='string'||typeof newPassword!=='string'||!oldPassword||newPassword.length<6||newPassword.length>1024)return {ok:false,status:400,error:'invalid_password'};
  return store.mutate(actor.username,async payload=>{
   const user=(payload.users||[]).find(u=>u.id===actor.id&&u.username===actor.username);
   if(!user||typeof user.password!=='string')return {ok:false,status:401,error:'invalid_credentials'};
   let valid=false;
   if(user.password.startsWith('scrypt$'))valid=await verifyPassword(oldPassword,user.password);
   else {const a=Buffer.from(oldPassword),b=Buffer.from(user.password);valid=a.length===b.length&&crypto.timingSafeEqual(a,b)}
   if(!valid)return {ok:false,status:401,error:'invalid_credentials'};
   user.password=await hashPassword(newPassword);return {ok:true};
  });
 }
 async function changeLoginName(actor,input){
  const name=typeof input?.loginName==='string'?input.loginName.trim().toLowerCase():'';
  if(!/^[a-z0-9._-]{3,64}$/.test(name))return {ok:false,status:400,error:'invalid_login_name'};
  return store.mutate(actor.username,async payload=>{
   const users=payload.users||[],user=users.find(u=>u.id===actor.id&&u.username===actor.username);
   if(!user)return {ok:false,status:401,error:'unauthorized'};
   if(users.some(u=>u.id!==user.id&&((u.loginName||u.username).toLowerCase()===name||u.username.toLowerCase()===name)))return {ok:false,status:409,error:'username_exists'};
   user.loginName=name;return {ok:true,loginName:name};
  });
 }
 return {save,remove,changePassword,changeLoginName};
}
module.exports={createUserManager};
