'use strict';
const http=require('node:http');
const {createLiveEvents}=require('./live-events');
const {createSnapshotCache}=require('./snapshot-cache');
const fs=require('node:fs/promises');
const path=require('node:path');
const {gzip}=require('node:zlib');
const {promisify}=require('node:util');
const gzipAsync=promisify(gzip);
const MAX=8*1024*1024;
function createApi({store,authorize,projectState,allowWrite,sessions,publicDir,userManager,pushManager}){
 if(!store||typeof authorize!=='function'||typeof projectState!=='function'||typeof allowWrite!=='function')throw Error('Missing authorization policy');
 const hub=createLiveEvents();
 const snapshots=createSnapshotCache();
 const attempts=new Map();
 const staticFiles=new Map();
 const safeUser=user=>({id:user.id,username:user.username,loginName:user.loginName||user.username,displayName:user.displayName,role:user.role,canDelete:!!user.canDelete,canExport:!!user.canExport});
 function json(res,status,body){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(body))}
 const server=http.createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://localhost');
   const assets={'/manifest.webmanifest':'application/manifest+json; charset=utf-8','/notify-sw.js':'text/javascript; charset=utf-8','/notification-client.js':'text/javascript; charset=utf-8','/icon-192.png':'image/png','/icon-512.png':'image/png'};
   if(publicDir&&req.method==='GET'&&assets[url.pathname]){const body=await fs.readFile(path.join(publicDir,url.pathname.slice(1)));res.writeHead(200,{'Content-Type':assets[url.pathname],'Cache-Control':'no-cache'});return res.end(body)}
   if(publicDir&&req.method==='GET'&&(url.pathname==='/'||url.pathname==='/index.html'||url.pathname==='/sync-client.js')){
    const name=url.pathname==='/sync-client.js'?'sync-client.js':'index.html';
    if(!staticFiles.has(name))staticFiles.set(name,(async()=>{const body=await fs.readFile(path.join(publicDir,name));return {body,gz:await gzipAsync(body)}})());
    const file=await staticFiles.get(name);const acceptsGzip=String(req.headers['accept-encoding']||'').split(',').some(item=>{const [name,...params]=item.trim().toLowerCase().split(';');const q=params.find(p=>p.trim().startsWith('q='));return name==='gzip'&&(!q||Number(q.trim().slice(2))>0)});
    const headers={'Content-Type':name.endsWith('.js')?'text/javascript; charset=utf-8':'text/html; charset=utf-8','Cache-Control':'no-store','Vary':'Accept-Encoding'};
    if(acceptsGzip)headers['Content-Encoding']='gzip';res.writeHead(200,headers);return res.end(acceptsGzip?file.gz:file.body);
   }
   if(sessions&&url.pathname==='/api/session'&&req.method==='POST'){
    const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>8192)return json(res,413,{error:'too_large'});chunks.push(chunk)}
    let body;try{body=JSON.parse(Buffer.concat(chunks).toString('utf8'))}catch{return json(res,400,{error:'invalid_json'})}
    const now=Date.now(),username=typeof body.username==='string'?body.username.slice(0,128).toLowerCase():'';
    const key=(req.socket.remoteAddress||'unknown')+'|'+username;let state=attempts.get(key);
    for(const [k,v] of attempts)if(now-v.since>600000)attempts.delete(k);
    if(attempts.size>5000)attempts.delete(attempts.keys().next().value);
    if(!state||now-state.since>600000){state={since:now,count:0};attempts.set(key,state)}
    if(state.count>=8)return json(res,429,{error:'too_many_attempts'});
    state.count++;const session=await sessions.login(body.username,body.password);if(!session)return json(res,401,{error:'invalid_credentials'});
    attempts.delete(key);res.setHeader('Set-Cookie',session.cookie);
    const user=await sessions.authenticate({headers:{cookie:session.cookie}});return json(res,200,{user:safeUser(user)});
   }
   const user=await authorize(req);
   if(!user)return json(res,401,{error:'unauthorized'});
   if(sessions&&url.pathname==='/api/session'&&req.method==='DELETE'){
    res.setHeader('Set-Cookie',sessions.logoutRequest(req));return json(res,200,{ok:true});
   }
   if(sessions&&url.pathname==='/api/session'&&req.method==='GET')return json(res,200,{user:safeUser(user)});
   if(userManager&&url.pathname==='/api/profile/login-name'&&req.method==='POST'){
    const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>8192)return json(res,413,{error:'too_large'});chunks.push(chunk)}
    let body;try{body=JSON.parse(Buffer.concat(chunks).toString('utf8'))}catch{return json(res,400,{error:'invalid_json'})}
    const result=await userManager.changeLoginName(user,body);if(!result.ok)return json(res,result.status||400,{error:result.error||'invalid_request'});
    hub.publish(result.state.revision);return json(res,200,{ok:true,loginName:result.loginName});
   }
   if(userManager&&url.pathname==='/api/profile/password'&&req.method==='POST'){
    const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>8192)return json(res,413,{error:'too_large'});chunks.push(chunk)}
    let body;try{body=JSON.parse(Buffer.concat(chunks).toString('utf8'))}catch{return json(res,400,{error:'invalid_json'})}
    const result=await userManager.changePassword(user,body);
    return result.ok?json(res,200,{ok:true}):json(res,result.status||400,{error:result.error||'invalid_request'});
   }
   if(userManager&&url.pathname==='/api/users'&&(req.method==='POST'||req.method==='DELETE')){
    const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>8192)return json(res,413,{error:'too_large'});chunks.push(chunk)}
    let body;try{body=JSON.parse(Buffer.concat(chunks).toString('utf8'))}catch{return json(res,400,{error:'invalid_json'})}
    const result=req.method==='POST'?await userManager.save(user,body):await userManager.remove(user,body.id);
    if(!result.ok)return json(res,result.status||400,{error:result.error||'invalid_request'});
    hub.publish(result.state.revision);return json(res,200,{ok:true});
   }
   if(url.pathname==='/api/push/key'&&req.method==='GET')return pushManager?json(res,200,{publicKey:pushManager.publicKey}):json(res,503,{error:'push_unavailable'});
   if(url.pathname==='/api/push/subscription'&&(req.method==='POST'||req.method==='DELETE')){
    if(!pushManager)return json(res,503,{error:'push_unavailable'});
    const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>8192)return json(res,413,{error:'too_large'});chunks.push(chunk)}
    let body;try{body=JSON.parse(Buffer.concat(chunks).toString('utf8'))}catch{return json(res,400,{error:'invalid_json'})}
    if(req.method==='DELETE'){await pushManager.unsubscribe(user.username,body.endpoint);return json(res,200,{ok:true})}
    if(!await pushManager.subscribe(user.username,body.subscription))return json(res,400,{error:'invalid_subscription'});return json(res,200,{ok:true});
   }
   if(url.pathname==='/api/chat/stream'&&req.method==='GET')return hub.subscribe(req,res);
   if(url.pathname==='/api/state'&&req.method==='GET'){
    const state=await projectState(user,await store.read());
    return json(res,200,{...state,baseline:snapshots.issue(user.username,state.payload)});
   }
   if(url.pathname==='/api/state'&&req.method==='POST'){
    const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>MAX)return json(res,413,{error:'too_large'});chunks.push(chunk)}
    let body;try{body=JSON.parse(Buffer.concat(chunks).toString('utf8'))}catch{return json(res,400,{error:'invalid_json'})}
    if(!body||!body.baseline||!body.payload)return json(res,400,{error:'baseline_and_payload_required'});
    const base=snapshots.get(user.username,body.baseline);
    if(!base)return json(res,409,{error:'baseline_expired'});
    const result=await store.commit({base,payload:body.payload,updatedBy:user.username,
      validate:async current=>allowWrite(user,base,body.payload,await projectState(user,current),current)});
    if(!result.ok)return json(res,result.status,{error:result.status===403?'forbidden':'conflict',conflicts:result.conflicts});
    if(pushManager)pushManager.onCommit(result.previous,result.state);
    const projected=await projectState(user,result.state);
    hub.publish(result.state.revision);return json(res,200,{ok:true,state:{...projected,baseline:snapshots.issue(user.username,projected.payload)}});
   }
   json(res,404,{error:'not_found'});
  }catch(err){if(!res.headersSent)json(res,500,{error:'server_error'});else res.end()}
 });return {server,hub};
}
module.exports={createApi};
