'use strict';
const clone=x=>JSON.parse(JSON.stringify(x));
function safeUser(user){return {id:user.id,username:user.username,displayName:user.displayName,role:user.role,canDelete:!!user.canDelete,canExport:!!user.canExport}}
function visible(item,user){return !!item&&!item.pendingReferralId&&(!item.assignedTo||item.assignedTo===user.username)}
function privateMessageVisible(m,user){
 if(!m||m.del||m.deleted)return false;
 if(m.c==='all')return true;
 if(m.from===user.username||m.to===user.username)return true;
 return typeof m.c==='string'&&m.c.split('|').includes(user.username);
}
function projectSnapshot(user,state){
 if(!user||!state||!state.payload)throw Error('user and snapshot required');
 const result=clone(state);const p=result.payload;
 if(Array.isArray(p.users))p.users=p.users.map(safeUser);
 for(const key of ['customers','deals','missedCalls'])if(Array.isArray(p[key]))p[key]=p[key].filter(item=>visible(item,user));
 if(p.ws&&typeof p.ws==='object'){
   if(Array.isArray(p.ws.msgs))p.ws.msgs=p.ws.msgs.filter(m=>privateMessageVisible(m,user));
   if(Array.isArray(p.ws.tasks))p.ws.tasks=p.ws.tasks.filter(t=>t.from===user.username||t.to===user.username);
   // Read receipts, pins and profile internals require a dedicated privacy policy.
   delete p.ws.readBy;delete p.ws.pins;delete p.ws.hiddenConvs;
 }
 return result;
}
module.exports={projectSnapshot};
