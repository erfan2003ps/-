'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const os=require('node:os');
const path=require('node:path');
const {createPushManager,validSubscription}=require('./push-manager');
const fake=(id)=>({endpoint:'https://fcm.googleapis.com/fcm/send/'+id,keys:{p256dh:'A'.repeat(87),auth:'B'.repeat(22)}});
test('push targets recipient, persists subscriptions and rejects untrusted endpoints',async t=>{
 const folder=await fs.mkdtemp(path.join(os.tmpdir(),'mg-push-test-'));t.after(()=>fs.rm(folder,{recursive:true,force:true}));const sent=[];const transport={generateVAPIDKeys:()=>({publicKey:'public',privateKey:'private'}),setVapidDetails(){},sendNotification:async s=>sent.push(s.endpoint)};const filename=path.join(folder,'push.json');
 const service=await createPushManager({filename,transport});assert.equal(validSubscription({...fake('bad'),endpoint:'https://127.0.0.1/admin'}),false);assert.equal(await service.subscribe('alice',fake('one')),true);assert.equal(await service.subscribe('bob',fake('two')),true);
 const previous={payload:{ws:{msgs:[]}}};const state={payload:{users:[{username:'alice'},{username:'bob'}],ws:{msgs:[{id:'m1',from:'alice',to:'bob',c:'alice|bob'}]}}};await service.onCommit(previous,state);assert.deepEqual(sent,[fake('two').endpoint]);sent.length=0;await service.onCommit(state,state);assert.equal(sent.length,0);
 const loaded=await createPushManager({filename,transport});await loaded.unsubscribe('alice',fake('two').endpoint);await loaded.notifyUsers(['bob']);assert.deepEqual(sent,[fake('two').endpoint]);
});
