self.addEventListener('push', event => {
  let data={};try{data=event.data?.json()||{}}catch{}
  event.waitUntil(self.registration.showNotification(data.title||'مشهد گستر',{body:data.body||'پیام جدید دارید.',icon:'/icon-192.png',badge:'/icon-192.png',dir:'rtl',data:{url:'/'}}));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(async list => {
    for (const client of list) if (new URL(client.url).origin === self.location.origin) { await client.focus(); client.postMessage({type:'mg-open-work-chat'}); return; }
    await clients.openWindow('/');
  }));
});
