'use strict';
(()=>{
 let baseline=null, baselineUser='', registrationPromise=null, pushReady=false, subscriptionUser='';
 const supported=()=>window.isSecureContext && 'Notification' in window && 'serviceWorker' in navigator;
 function registration(){return registrationPromise||(registrationPromise=navigator.serviceWorker.register('/notify-sw.js').catch(()=>null))}
 async function showNotice(title,body){if(!supported()||Notification.permission!=='granted')return;const reg=await registration();if(reg)await reg.showNotification(title,{body,icon:'/icon-192.png',tag:'mg-chat-'+Date.now(),dir:'rtl'}).catch(()=>{});}
 async function enablePush(user){
  if(!user||!supported()||Notification.permission!=='granted'||!('PushManager' in window))throw Error('push unsupported');
  const response=await fetch('/api/push/key',{credentials:'same-origin',cache:'no-store'});if(!response.ok)throw Error('push server unavailable');const key=(await response.json()).publicKey;
  const reg=await registration();if(!reg)throw Error('service worker unavailable');
  const normalized=key.replace(/-/g,'+').replace(/_/g,'/');const bytes=Uint8Array.from(atob(normalized.padEnd(Math.ceil(normalized.length/4)*4,'=')),c=>c.charCodeAt(0));
  let sub=await reg.pushManager.getSubscription();
  if(sub&&sub.options.applicationServerKey){const old=new Uint8Array(sub.options.applicationServerKey);if(old.length!==bytes.length||old.some((v,i)=>v!==bytes[i])){await sub.unsubscribe();sub=null}}
  if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:bytes});
  const saved=await fetch('/api/push/subscription',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({subscription:sub.toJSON()})});if(!saved.ok)throw Error('subscription failed');pushReady=true;subscriptionUser=user;
 }
 function panel(){
  if(document.getElementById('mg-notify-prompt'))return;
  const d=document.createElement('div');d.id='mg-notify-prompt';d.setAttribute('role','dialog');d.setAttribute('aria-label','فعال کردن اعلان‌ها');
  d.style.cssText='position:fixed;z-index:9999;bottom:18px;left:18px;right:18px;max-width:440px;margin:auto;padding:18px;border-radius:20px;background:#fffdf8;color:#27251f;box-shadow:0 12px 45px #0004;border:1px solid #d8bf8a;direction:rtl;font:14px Vazirmatn,sans-serif';
  const msg=document.createElement('p');msg.textContent='برای اطلاع از پیام همکاران و ارجاع‌ها، اعلان‌های مرورگر را فعال کنید.';
  const yes=document.createElement('button');yes.textContent='فعال‌کردن اعلان‌ها';yes.style.cssText='padding:9px 14px;border:0;border-radius:12px;background:#b99751;color:#fff;margin:8px 0 0 8px;cursor:pointer';
  const no=document.createElement('button');no.textContent='بعداً';no.style.cssText='padding:9px 14px;border:0;border-radius:12px;background:#eee;cursor:pointer';
  yes.onclick=async()=>{if(!supported()){msg.textContent='اعلان در این مرورگر یا اتصال پشتیبانی نمی‌شود.';return}if(Notification.permission==='denied'){msg.textContent='اعلان‌ها مسدود هستند؛ از تنظیمات مرورگر برای این سایت آن‌ها را فعال کنید.';return}const result=await Notification.requestPermission();if(result==='granted'){try{await enablePush(window.__me?.username);d.remove();showNotice('اعلان‌های مشهد گستر فعال شد','پیام‌های جدید برای این دستگاه فعال شد.')}catch(e){msg.textContent='فعال‌سازی کامل نشد؛ اتصال یا تنظیمات اعلان را بررسی کنید.'}}else msg.textContent='اجازه اعلان داده نشد؛ می‌توانید بعداً از تنظیمات مرورگر آن را فعال کنید.'};
  no.onclick=()=>d.remove();d.append(msg,yes,no);document.body.append(d);
 }
 window.mgNotifyDisable=async()=>{
  if(!('serviceWorker' in navigator))return;const reg=await navigator.serviceWorker.getRegistration('/');const sub=reg&&await reg.pushManager.getSubscription();
  if(sub){const result=await fetch('/api/push/subscription',{method:'DELETE',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({endpoint:sub.endpoint})});if(!result.ok)throw Error('unsubscribe failed');await sub.unsubscribe()}pushReady=false;subscriptionUser='';
 };
 window.mgNotifySettings=panel;
 window.mgObserveMessages=(messages,user)=>{
  if(!user)return;const list=Array.isArray(messages)?messages:[];const ids=new Set(list.map(m=>m.id));
  if(baseline&&baselineUser===user){const arrived=list.filter(m=>m.id&&!baseline.has(m.id)&&!m.del&&m.from!==user&&(m.to===user||m.c==='all'));if(arrived.length&&!pushReady)showNotice('پیام جدید در مشهد گستر',arrived.length===1?'پیام یا ارجاع جدیدی دریافت کردید.':arrived.length+' پیام یا ارجاع جدید دریافت کردید.');}
  baseline=ids;baselineUser=user;
  if(supported()&&Notification.permission==='granted'&&subscriptionUser!==user){subscriptionUser=user;enablePush(user).catch(()=>{pushReady=false;subscriptionUser='';});}
  if(supported()&&Notification.permission==='default'&&!sessionStorage.getItem('mg-notify-asked')){sessionStorage.setItem('mg-notify-asked','1');setTimeout(panel,1800)}
 };
 if('serviceWorker' in navigator)navigator.serviceWorker.addEventListener('message',e=>{if(e.data?.type==='mg-open-work-chat'){document.querySelector('[data-tab=work]')?.click();setTimeout(()=>document.querySelector('[data-ws-sub=c]')?.click(),250)}});
})();
