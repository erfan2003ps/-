/* Contract for the experimental server. This file is not yet wired to the UI. */
(function(root){
 'use strict';
 const missing=Symbol('missing');
 const object=x=>x!==missing&&x!==null&&typeof x==='object'&&!Array.isArray(x);
 function equal(a,b){
  if(a===missing||b===missing)return a===b;
  if(a===b)return true;
  if(Array.isArray(a)||Array.isArray(b))return Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((v,i)=>equal(v,b[i]));
  if(object(a)&&object(b)){const keys=Object.keys(a),other=Object.keys(b);return keys.length===other.length&&keys.every(k=>Object.prototype.hasOwnProperty.call(b,k)&&equal(a[k],b[k]))}
  return false;
 }
 function rebase(base,local,remote){
  const conflicts=[];
  function check(value,path){
   if(Array.isArray(value)){
    const ids=new Set();for(const x of value)if(object(x)&&typeof x.id==='string'){
     if(ids.has(x.id)){conflicts.push((path||'$')+'[duplicate id]');break}ids.add(x.id);
    }
    value.forEach((x,i)=>check(x,path+'['+i+']'));
   }else if(object(value))for(const k of Object.keys(value))check(value[k],path?path+'.'+k:k);
  }
  [base,local,remote].forEach(x=>check(x,''));
  if(conflicts.length)return {payload:remote,conflicts:[...new Set(conflicts)]};
  function merge(b,l,r,path){
   if(equal(l,b))return r;if(equal(r,b)||equal(l,r))return l;
   if([b,l,r].every(Array.isArray)&&[...b,...l,...r].every(x=>object(x)&&typeof x.id==='string')){
    const maps=[b,l,r].map(items=>new Map(items.map(x=>[x.id,x])));
    if([b,l,r].some((items,i)=>items.length!==maps[i].size)){conflicts.push(path+'[duplicate id]');return r}
    const ids=[...new Set([...maps[2].keys(),...maps[1].keys(),...maps[0].keys()])];
    return ids.map(id=>merge(...maps.map(m=>m.has(id)?m.get(id):missing),path+'['+id+']')).filter(x=>x!==missing);
   }
   if([b,l,r].every(object)){
    const out={};for(const key of new Set([...Object.keys(b),...Object.keys(l),...Object.keys(r)])){
     const v=[b,l,r].map(x=>Object.prototype.hasOwnProperty.call(x,key)?x[key]:missing);
     const result=merge(...v,path?path+'.'+key:key);
     if(result!==missing)Object.defineProperty(out,key,{value:result,enumerable:true,writable:true,configurable:true});
    }return out;
   }
   conflicts.push(path||'$');return r;
  }
  const payload=merge(base,local,remote,'');return {payload,conflicts};
 }
 function createSyncClient(fetcher){
  let baseline=null;
  async function request(url,options){
   const response=await fetcher(url,{credentials:'same-origin',...options});
   const data=await response.json();
   if(!response.ok){const error=new Error(data.error||'request_failed');error.status=response.status;error.data=data;throw error}
   return data;
  }
  async function login(username,password){
   return request('/api/session',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password})});
  }
  async function session(){return request('/api/session',{method:'GET'})}
  async function logout(){const result=await request('/api/session',{method:'DELETE'});baseline=null;return result}
  async function load(){
   const data=await request('/api/state',{method:'GET'});
   if(!data.baseline||!data.payload)throw Error('invalid_snapshot');
   baseline=data.baseline;return data;
  }
  async function save(payload){
   if(!baseline)throw Error('snapshot_required');
   const data=await request('/api/state',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({baseline,payload})});
   if(!data.state||!data.state.baseline)throw Error('invalid_snapshot');
   baseline=data.state.baseline;return data.state;
  }
  return {login,session,logout,load,save,rebase,clear:()=>{baseline=null}};
 }
 if(typeof module!=='undefined'&&module.exports)module.exports={createSyncClient,rebase};
 else {root.createSyncClient=createSyncClient;root.rebaseSyncPayload=rebase}
})(typeof globalThis!=='undefined'?globalThis:this);
