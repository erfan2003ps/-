'use strict';
const {isDeepStrictEqual}=require('node:util');
function canSee(user,task){return !!(user && task && (user.role==='admin'||task.from===user.username||task.to===user.username));}
function canSeeMessage(user,msg){if(!user||!msg)return false;if(user.role==='admin'||msg.c==='all'||msg.from===user.username||msg.to===user.username)return true;return typeof msg.c==='string'&&msg.c.split('|').includes(user.username);}
function projectState(user,state){
 const result=structuredClone(state);
 result.payload.users=(result.payload.users||[]).map(({id,username,loginName,displayName,role,canDelete,canExport})=>({id,username,loginName,displayName,role,canDelete,canExport}));
 if(result.payload.ws && Array.isArray(result.payload.ws.tasks))result.payload.ws.tasks=result.payload.ws.tasks.filter(t=>canSee(user,t));
 if(result.payload.ws && Array.isArray(result.payload.ws.msgs))result.payload.ws.msgs=result.payload.ws.msgs.filter(m=>canSeeMessage(user,m));
 return result;
}
function allowWrite(user,base,payload,current){
 if(!isDeepStrictEqual(base.users,payload.users))return false;
 const previousProfiles={...(base.ws?.profiles||{})},nextProfiles={...(payload.ws?.profiles||{})};
 delete previousProfiles[user.username];delete nextProfiles[user.username];
 if(!isDeepStrictEqual(previousProfiles,nextProfiles))return false;
 const tasks=payload.ws?.tasks||[],messages=payload.ws?.msgs||[],existingTasks=current.payload.ws?.tasks||[],existingMessages=current.payload.ws?.msgs||[];
 if(![tasks,messages,existingTasks,existingMessages].every(Array.isArray))return false;
 const taskMap=new Map(existingTasks.map(t=>[t.id,t])),msgMap=new Map(existingMessages.map(m=>[m.id,m]));
 const taskIds=new Set(),msgIds=new Set();
 for(const task of tasks){
  if(!task||typeof task.id!=='string'||taskIds.has(task.id))return false;taskIds.add(task.id);
  const old=taskMap.get(task.id);
  if(old&&!canSee(user,old))return false;
  if(user.role!=='admin'){
   if(!canSee(user,task))return false;
   if(old&&(old.from!==task.from||old.to!==task.to))return false;
   if(!old&&task.from!==user.username){const ref=msgMap.get(task.refMsgId);if(!ref||ref.type!=='ref'||ref.to!==user.username||ref.from!==task.from||task.to!==user.username)return false;}
  }
 }
 for(const msg of messages){
  if(!msg||typeof msg.id!=='string'||msgIds.has(msg.id))return false;msgIds.add(msg.id);
  const old=msgMap.get(msg.id);if(old&&!canSeeMessage(user,old))return false;
  if(user.role!=='admin'){
   if(!canSeeMessage(user,msg))return false;
   if(old&&(old.from!==msg.from||old.c!==msg.c))return false;
   if(!old&&msg.from!==user.username)return false;
  }
 }
 return true;
}
module.exports={canSee,canSeeMessage,projectState,allowWrite};
