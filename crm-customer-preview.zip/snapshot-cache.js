'use strict';
const crypto=require('node:crypto');

// The client receives an opaque identifier, never authority to invent its base.
function createSnapshotCache({now=()=>Date.now(),ttlMs=10*60*1000,maxEntries=128}={}){
 const entries=new Map();
 function prune(){
  const time=now();for(const [key,item] of entries)if(item.expires<=time)entries.delete(key);
  while(entries.size>=maxEntries)entries.delete(entries.keys().next().value);
 }
 function issue(username,payload){
  prune();const id=crypto.randomBytes(24).toString('base64url');
  // Match the exact JSON representation sent to the browser (undefined keys are omitted).
  entries.set(id,{username,payload:JSON.parse(JSON.stringify(payload)),expires:now()+ttlMs});return id;
 }
 function get(username,id){
  if(typeof id!=='string')return null;const item=entries.get(id);
  if(!item||item.username!==username)return null;
  if(item.expires<=now()){entries.delete(id);return null}
  return structuredClone(item.payload);
 }
 return {issue,get};
}
module.exports={createSnapshotCache};
