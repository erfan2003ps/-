'use strict';
const fs=require('node:fs/promises');
const path=require('node:path');
const crypto=require('node:crypto');
const webpush=require('web-push');

function allowedEndpoint(value){try{const u=new URL(value);const host=u.hostname.toLowerCase();return u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&['fcm.googleapis.com','updates.push.services.mozilla.com','push.services.mozilla.com'].some(x=>host===x) || (u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&['push.apple.com','notify.windows.com'].some(x=>host===x||host.endsWith('.'+x)))}catch{return false}}
function validSubscription(sub){return !!(sub&&typeof sub.endpoint==='string'&&sub.endpoint.length<4096&&allowedEndpoint(sub.endpoint)&&sub.keys&&typeof sub.keys.p256dh==='string'&&typeof sub.keys.auth==='string'&&/^[A-Za-z0-9_-]{80,100}$/.test(sub.keys.p256dh)&&/^[A-Za-z0-9_-]{20,30}$/.test(sub.keys.auth))}
async function createPushManager({filename,transport=webpush,contact=process.env.PUSH_CONTACT||'mailto:admin@example.com'}){
 let queue=Promise.resolve(),data;
 try{data=JSON.parse(await fs.readFile(filename,'utf8'));if(!data.keys||!data.keys.publicKey||!data.keys.privateKey||!Array.isArray(data.subscriptions))throw Error('Invalid push store')}catch(err){if(err.code!=='ENOENT')throw err;data={keys:transport.generateVAPIDKeys(),subscriptions:[]};await persist()}
 transport.setVapidDetails(contact,data.keys.publicKey,data.keys.privateKey);
 async function persist(){await fs.mkdir(path.dirname(filename),{recursive:true});const temp=filename+'.tmp-'+crypto.randomBytes(6).toString('hex');try{await fs.writeFile(temp,JSON.stringify(data),{encoding:'utf8',mode:0o600,flag:'wx'});await fs.rename(temp,filename)}catch(e){await fs.rm(temp,{force:true}).catch(()=>{});throw e}}
 function mutate(fn){const operation=queue.then(async()=>{const result=fn();await persist();return result});queue=operation.catch(()=>{});return operation}
 async function subscribe(username,subscription){if(!username||!validSubscription(subscription))return false;await mutate(()=>{data.subscriptions=data.subscriptions.filter(x=>x.subscription.endpoint!==subscription.endpoint);data.subscriptions.push({username,subscription:{endpoint:subscription.endpoint,keys:{p256dh:subscription.keys.p256dh,auth:subscription.keys.auth}}})});return true}
 async function unsubscribe(username,endpoint){await mutate(()=>{data.subscriptions=data.subscriptions.filter(x=>!(x.username===username&&x.subscription.endpoint===endpoint))})}
 async function notifyUsers(users){const targets=new Set(users);await queue;const entries=data.subscriptions.filter(x=>targets.has(x.username));const expired=[];await Promise.all(entries.map(async entry=>{try{await transport.sendNotification(entry.subscription,JSON.stringify({title:'مشهد گستر',body:'پیام یا ارجاع جدیدی دریافت کردید.',url:'/'}),{TTL:3600,urgency:'normal'})}catch(e){if(e.statusCode===404||e.statusCode===410)expired.push(entry.subscription.endpoint);else console.error('Push delivery failed:',e.statusCode||e.code||'unknown')}}));if(expired.length)await mutate(()=>{data.subscriptions=data.subscriptions.filter(x=>!expired.includes(x.subscription.endpoint))})}
 function onCommit(previous,current){const before=new Set((previous.payload.ws?.msgs||[]).map(m=>m.id));const users=(current.payload.users||[]).map(u=>u.username);const result=new Set();for(const m of current.payload.ws?.msgs||[]){if(!m||!m.id||before.has(m.id)||m.del||!m.from)continue;let recipients=m.c==='all'?users:(m.to?[m.to]:typeof m.c==='string'?m.c.split('|'):[]);for(const recipient of recipients)if(recipient!==m.from&&users.includes(recipient))result.add(recipient)}if(result.size)return notifyUsers([...result]).catch(e=>console.error('Push dispatch failed:',e.code||e.message))}
 return {publicKey:data.keys.publicKey,subscribe,unsubscribe,onCommit,notifyUsers};
}
module.exports={createPushManager,validSubscription,allowedEndpoint};
