'use strict';
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const scrypt = promisify(crypto.scrypt);
async function hashPassword(password){
 if(typeof password!=='string'||password.length===0||password.length>1024) throw new Error('invalid password');
 const salt=crypto.randomBytes(16).toString('hex');
 const key=await scrypt(password,salt,64,{N:16384,r:8,p:1});
 return 'scrypt$16384$8$1$'+salt+'$'+key.toString('hex');
}
async function verifyPassword(password,encoded){
 if(typeof password!=='string'||typeof encoded!=='string'||password.length>1024)return false;
 const parts=encoded.split('$');
 if(parts.length!==6||parts[0]!=='scrypt'||parts[1]!=='16384'||parts[2]!=='8'||parts[3]!=='1'||! /^[0-9a-f]{32}$/.test(parts[4])||! /^[0-9a-f]{128}$/.test(parts[5]))return false;
 const key=await scrypt(password,parts[4],64,{N:16384,r:8,p:1});const stored=Buffer.from(parts[5],'hex');
 return crypto.timingSafeEqual(key,stored);
}
module.exports={hashPassword,verifyPassword};
