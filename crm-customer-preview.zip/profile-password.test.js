'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const os=require('node:os');
const path=require('node:path');
const {createStore}=require('./sync-store');
const {createUserManager}=require('./user-management');
const {verifyPassword}=require('./passwords');
const {startDemo}=require('./local-demo-server');
const {allowWrite}=require('./task-policy');

test('each user can change only their own password with the current password',async t=>{
 const folder=await fs.mkdtemp(path.join(os.tmpdir(),'mg-profile-test-'));
 t.after(()=>fs.rm(folder,{recursive:true,force:true}));
 const store=createStore(path.join(folder,'db.json'));
 await store.commit({base:{},payload:{users:[{id:'a',username:'a',password:'oldpass',role:'agent'},{id:'b',username:'b',password:'otherpass',role:'agent'}]}});
 const manager=createUserManager(store),actor={id:'a',username:'a',role:'agent'};
 assert.equal((await manager.changePassword(actor,{oldPassword:'wrong',newPassword:'newpass'})).ok,false);
 assert.equal((await manager.changePassword(actor,{oldPassword:'oldpass',newPassword:'newpass',id:'b'})).ok,true);
 const users=(await store.read()).payload.users;
 assert.equal(await verifyPassword('newpass',users[0].password),true);
 assert.equal(users[1].password,'otherpass');
 assert.equal((await manager.save(actor,{username:'x'})).status,403);
});

test('profile endpoint requires login and changes password only for the signed-in user',async t=>{
 const demo=await startDemo();t.after(()=>demo.close());
 const request=(pathname,options={})=>fetch(demo.url+pathname,options);
 const body={oldPassword:'123456',newPassword:'newpass'};
 assert.equal((await request('/api/profile/password',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)})).status,401);
 const login=await request('/api/session',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({username:'sales1',password:'123456'})});
 const cookie=login.headers.get('set-cookie').split(';')[0];
 const headers={'content-type':'application/json',cookie};
 assert.equal((await request('/api/users',{method:'POST',headers,body:JSON.stringify({username:'x'})})).status,403);
 assert.equal((await request('/api/profile/password',{method:'POST',headers,body:JSON.stringify({...body,oldPassword:'wrong'})})).status,401);
 assert.equal((await request('/api/profile/password',{method:'POST',headers,body:JSON.stringify(body)})).status,200);
 assert.equal((await request('/api/session',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({username:'sales1',password:'newpass'})})).status,200);
});

test('login name changes without changing internal identity and existing session',async t=>{
 const demo=await startDemo();t.after(()=>demo.close());
 const request=(pathname,options={})=>fetch(demo.url+pathname,options);
 const loginBody=(username,password='123456')=>({method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({username,password})});
 const login=await request('/api/session',loginBody('sales1'));const cookie=login.headers.get('set-cookie').split(';')[0];
 const headers={'content-type':'application/json',cookie};
 const change=name=>request('/api/profile/login-name',{method:'POST',headers,body:JSON.stringify({loginName:name})});
 assert.equal((await change('admin')).status,409);
 assert.equal((await change('new.agent')).status,200);
 assert.equal((await request('/api/session',{headers:{cookie}})).status,200);
 assert.equal((await request('/api/session',loginBody('sales1'))).status,401);
 const again=await request('/api/session',loginBody('new.agent'));assert.equal(again.status,200);
 const user=(await again.json()).user;assert.equal(user.username,'sales1');assert.equal(user.loginName,'new.agent');
 assert.equal((await demo.store.read()).payload.users.find(u=>u.id==='demo-agent').username,'sales1');
});

test('a user cannot modify another user profile through state sync',()=>{
 const user={username:'a',role:'agent'},base={users:[],ws:{tasks:[],msgs:[],profiles:{a:{bio:'old'},b:{bio:'private'}}}};
 const payload=structuredClone(base);payload.ws.profiles.b.bio='changed';
 assert.equal(allowWrite(user,base,payload,{payload:base}),false);
 payload.ws.profiles.b.bio='private';payload.ws.profiles.a.bio='updated';
 assert.equal(allowWrite(user,base,payload,{payload:base}),true);
});
