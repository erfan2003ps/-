'use strict';
const fs=require('node:fs/promises');
const path=require('node:path');
const crypto=require('node:crypto');
const {mergeSnapshots}=require('./sync-engine');
function createStore(filename,{mustExist=false}={}){
 let queue=Promise.resolve();
 async function read(){
  try {const data=JSON.parse(await fs.readFile(filename,'utf8')); if(!data||typeof data.payload!=='object'||data.payload===null||Array.isArray(data.payload))throw Error('Invalid stored payload');return data;}
  catch(e){if(e.code==='ENOENT'&&!mustExist)return {revision:0,updatedAt:null,updatedBy:null,payload:{}};throw e;}
 }
 async function write(current,payload,updatedBy){
  const next={...current,revision:(Number(current.revision)||0)+1,updatedAt:new Date().toISOString(),updatedBy:updatedBy||'کاربر',payload};
  await fs.mkdir(path.dirname(filename),{recursive:true});
  const temp=filename+'.tmp-'+crypto.randomBytes(8).toString('hex');
  try{await fs.writeFile(temp,JSON.stringify(next,null,2),{encoding:'utf8',flag:'wx',mode:0o600});await fs.rename(temp,filename)}catch(error){try{await fs.unlink(temp)}catch{}throw error}
  return next;
 }
 async function commit({base,payload,updatedBy,validate}){
  if(!base||typeof base!=='object'||Array.isArray(base)||!payload||typeof payload!=='object'||Array.isArray(payload))throw Error('Valid base and payload required');
  const operation=queue.then(async()=>{
   const current=await read();
   if(validate&&!await validate(current))return {ok:false,status:403};
   const result=mergeSnapshots(base,payload,current.payload);
   if(result.conflicts.length)return {ok:false,status:409,conflicts:result.conflicts,current};
   const next=await write(current,result.value,updatedBy);
   return {ok:true,status:200,state:next,previous:current};
  }); queue=operation.catch(()=>{});return operation;
 }
 async function mutate(updatedBy,change){
  const operation=queue.then(async()=>{
   const current=await read();const payload=structuredClone(current.payload);
   const result=await change(payload);if(!result||!result.ok)return result||{ok:false,status:400};
   return {...result,state:await write(current,payload,updatedBy)};
  });queue=operation.catch(()=>{});return operation;
 }
 return {read,commit,mutate};
}
module.exports={createStore};
