'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),os=require('node:os'),path=require('node:path');
const {startServer}=require('./server');
test('referral visibility, completion, unauthorized writes and concurrent records',async t=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'mg-policy-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));
 const users=['admin','alice','bob','cat'].map((username,i)=>({id:'u'+i,username,password:'demo-only',role:i?'agent':'admin',displayName:username}));
 const payload={users,customers:[],deals:[],quotes:[],ws:{tasks:[],msgs:[]}};
 const file=path.join(dir,'database.json');await fs.writeFile(file,JSON.stringify({revision:0,payload}));
 const {api,store}=await startServer({dataFile:file,port:0,host:'127.0.0.1'});t.after(()=>new Promise(r=>api.server.close(r)));
 const root='http://127.0.0.1:'+api.server.address().port;
 async function login(username){const r=await fetch(root+'/api/session',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({username,password:'demo-only'})});assert.equal(r.status,200);return r.headers.get('set-cookie').split(';')[0]}
 async function read(cookie){return (await fetch(root+'/api/state',{headers:{cookie}})).json()}
 async function save(cookie,s){return fetch(root+'/api/state',{method:'POST',headers:{cookie,'content-type':'application/json'},body:JSON.stringify({baseline:s.baseline,payload:s.payload})})}
 const a=await login('alice'),b=await login('bob'),c=await login('cat');let sa=await read(a);
 sa.payload.ws.tasks.push({id:'t',from:'alice',to:'bob',st:'p'});sa.payload.ws.msgs.push({id:'m',type:'ref',from:'alice',to:'bob',c:'alice|bob',taskId:'t'});assert.equal((await save(a,sa)).status,200);
 let sb=await read(b),sc=await read(c);assert.equal(sb.payload.ws.tasks.length,1);assert.equal(sc.payload.ws.tasks.length,0);assert.equal(sc.payload.ws.msgs.length,0);
 sb.payload.ws.tasks[0].st='f';sb.payload.ws.msgs.push({id:'done',type:'task_done',from:'bob',to:'alice',c:'alice|bob',taskId:'t'});assert.equal((await save(b,sb)).status,200);
 sa=await read(a);assert.equal(sa.payload.ws.tasks[0].st,'f');assert.equal(sa.payload.ws.msgs.some(m=>m.id==='done'),true);
 sc=await read(c);sc.payload.ws.tasks.push({id:'t',from:'cat',to:'cat'});assert.equal((await save(c,sc)).status,403);
 sa=await read(a);sb=await read(b);sa.payload.customers.push({id:'a'});sb.payload.customers.push({id:'b'});const result=await Promise.all([save(a,sa),save(b,sb)]);assert.deepEqual(result.map(r=>r.status),[200,200]);
 const final=await store.read();assert.equal(final.payload.customers.length,2);assert.equal(final.payload.ws.tasks.length,1);
});
