'use strict';
const crypto=require('node:crypto');
const {hashPassword}=require('./passwords');
function createUserManager(store){
 async function save(actor,input){
  if(actor.role!=='admin')return {ok:false,status:403,error:'forbidden'};
  const id=typeof input.id==='string'?input.id:'';
  const username=typeof input.username==='string'?input.username.trim().toLowerCase():'';
  const displayName=typeof input.displayName==='string'?input.displayName.trim():'';
  const password=typeof input.password==='string'?input.password:'';
  const role=input.role==='admin'?'admin':'agent';
  if(!username||username.length>128||!displayName||displayName.length>200||password.length>1024||(!id&&!password))return {ok:false,status:400,error:'invalid_user'};
  const hashed=password?await hashPassword(password):null;
  return store.mutate(actor.username,async payload=>{
   if(!Array.isArray(payload.users))return {ok:false,status:400,error:'invalid_users'};
   const existing=id?payload.users.find(u=>u.id===id):null;
   if(id&&!existing)return {ok:false,status:404,error:'user_not_found'};
   if(existing&&existing.username!==username)return {ok:false,status:400,error:'username_change_not_supported'};
   if(payload.users.some(u=>u.username.toLowerCase()===username&&u.id!==id))return {ok:false,status:409,error:'username_exists'};
   if(existing&&existing.username===actor.username&&role!=='admin')return {ok:false,status:400,error:'self_demotion_forbidden'};
   const next={...(existing||{}),id:id||'usr-'+crypto.randomBytes(12).toString('hex'),username,displayName,role,
    canDelete:role==='admin'||!!input.canDelete,canExport:role==='admin'||!!input.canExport};
   if(hashed)next.password=hashed;
   if(existing)Object.assign(existing,next);else payload.users.push(next);
   return {ok:true};
  });
 }
 async function remove(actor,id){
  if(actor.role!=='admin')return {ok:false,status:403,error:'forbidden'};
  return store.mutate(actor.username,async payload=>{
   if(!Array.isArray(payload.users))return {ok:false,status:400,error:'invalid_users'};
   const index=payload.users.findIndex(u=>u.id===id);
   if(index<0)return {ok:false,status:404,error:'user_not_found'};
   if(payload.users[index].username===actor.username)return {ok:false,status:400,error:'self_delete_forbidden'};
   payload.users.splice(index,1);return {ok:true};
  });
 }
 return {save,remove};
}
module.exports={createUserManager};
