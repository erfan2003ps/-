'use strict';
const path=require('node:path');
const {isDeepStrictEqual}=require('node:util');
const {createStore}=require('./sync-store');
const {createApi}=require('./candidate-api');
const {createSessions}=require('./auth-sessions');
const {createUserManager}=require('./user-management');

async function startServer({dataFile=path.join(__dirname,'data','database.json'),port=process.env.PORT||3000,host='0.0.0.0'}={}){
 const store=createStore(dataFile,{mustExist:true});
 const initial=await store.read();
 if(!Array.isArray(initial.payload.users)||!initial.payload.users.some(u=>u.role==='admin'))throw Error('Existing database has no administrator');
 const findUser=async username=>(await store.read()).payload.users.find(u=>u.username===username);
 const saveUser=async(updated,oldPassword)=>{
  const result=await store.mutate(updated.username,async payload=>{
   const user=payload.users.find(u=>u.id===updated.id);
   if(!user)return {ok:false};
   if(user.password===oldPassword)user.password=updated.password;
   else if(!String(user.password||'').startsWith('scrypt$'))return {ok:false};
   return {ok:true};
  });
  if(!result.ok)throw Error('Unable to migrate password');
 };
 const sessions=createSessions({findUser,saveUser});
 const api=createApi({store,sessions,userManager:createUserManager(store),authorize:req=>sessions.authenticate(req),
  publicDir:path.join(__dirname,'public'),
  projectState:async(user,state)=>{
   const result=structuredClone(state);
   result.payload.users=result.payload.users.map(({id,username,displayName,role,canDelete,canExport})=>({id,username,displayName,role,canDelete,canExport}));
   return result;
  },
  // All authenticated staff can access shared application data, as requested.
  // User account mutations go through the admin-only API instead of state writes.
  allowWrite:async(user,base,payload)=>isDeepStrictEqual(base.users,payload.users)});
 await new Promise((resolve,reject)=>{api.server.once('error',reject);api.server.listen(port,host,()=>{api.server.off('error',reject);resolve()})});
 return {api,store};
}
if(require.main===module)startServer().then(({api})=>console.log('CRM server listening on port '+api.server.address().port)).catch(err=>{console.error('Server not started:',err.message);process.exitCode=1});
module.exports={startServer};
