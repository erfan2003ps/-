'use strict';
// Isolated, synthetic-data preview only. This is not a production server.
const fs=require('node:fs/promises');
const os=require('node:os');
const path=require('node:path');
const {createStore}=require('./sync-store');
const {createApi}=require('./candidate-api');
const {createSessions}=require('./auth-sessions');
const {projectState,allowWrite}=require('./task-policy');
const {createPushManager}=require('./push-manager');
const {createUserManager}=require('./user-management');

async function startDemo(){
 const folder=await fs.mkdtemp(path.join(os.tmpdir(),'mg-synthetic-demo-'));
 const store=createStore(path.join(folder,'database.json'));
 const users=[{id:'demo-admin',username:'admin',password:'123456',displayName:'مدیر آزمایشی',role:'admin',canDelete:true,canExport:true},
  {id:'demo-agent',username:'sales1',password:'123456',displayName:'کارشناس آزمایشی',role:'agent',canDelete:true,canExport:true}];
 await store.commit({base:{},payload:{customers:[],deals:[],quotes:[],missedCalls:[],canceledDeals:[],categories:['عمومی'],allScenarios:[],users,ws:{tasks:[],msgs:[],profiles:{},pins:{},readBy:{},hiddenConvs:[],customPeers:[]}}});
 const findUser=async username=>(await store.read()).payload.users.find(u=>u.username===username);
 const saveUser=async updated=>{
  const current=await store.read();const payload=structuredClone(current.payload);
  const i=payload.users.findIndex(u=>u.id===updated.id);if(i<0)throw Error('Missing user');payload.users[i]=updated;
  const result=await store.commit({base:current.payload,payload,updatedBy:'demo-login'});if(!result.ok)throw Error('User update conflict');
 };
 const sessions=createSessions({findUser,saveUser});
 const pushManager=await createPushManager({filename:path.join(folder,'push-subscriptions.json')});
 const api=createApi({store,sessions,pushManager,userManager:createUserManager(store),authorize:req=>sessions.authenticate(req),
  projectState:async(user,state)=>projectState(user,state),
  allowWrite:async(user,base,payload,projected,current)=>allowWrite(user,base,payload,current),publicDir:path.join(__dirname,'public')});
 await new Promise(resolve=>api.server.listen(0,'127.0.0.1',resolve));
 return {api,store,folder,url:'http://127.0.0.1:'+api.server.address().port,
  close:async()=>{await new Promise(resolve=>api.server.close(resolve));await fs.rm(folder,{recursive:true,force:true})}};
}
if(require.main===module)startDemo().then(d=>console.log('Synthetic local demo: '+d.url)).catch(e=>{console.error(e);process.exitCode=1});
module.exports={startDemo};
